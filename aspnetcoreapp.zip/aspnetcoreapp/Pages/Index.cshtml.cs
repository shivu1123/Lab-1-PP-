using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace aspnetcoreapp.Pages;

public class IndexModel : PageModel
{
    private readonly ILogger<IndexModel> _logger;

    public IndexModel(ILogger<IndexModel> logger)
    {
        _logger = logger;
    }

    public void OnGet()
    {
    }

    public void OnPost()
    {
        if (Request.Method.Equals("POST", StringComparison.OrdinalIgnoreCase))
        {
            double num1 = double.Parse(Request.Form["num1"]);
            double num2 = 0;

            if (Request.Form["ADD"] == "ADD" || Request.Form["SUBTRACT"] == "SUBTRACT" ||
                Request.Form["MULTIPLY"] == "MULTIPLY" || Request.Form["DIVIDE"] == "DIVIDE" ||
                Request.Form["POWER"] == "POWER")
            {
                num2 = double.Parse(Request.Form["num2"]);
            }

            if (Request.Form["ADD"] == "ADD")
            {
                ViewData["result"] = num1 + num2;
            }
            else if (Request.Form["SUBTRACT"] == "SUBTRACT")
            {
                ViewData["result"] = num1 - num2;
            }
            else if (Request.Form["MULTIPLY"] == "MULTIPLY")
            {
                ViewData["result"] = num1 * num2;
            }
            else if (Request.Form["DIVIDE"] == "DIVIDE")
            {
                ViewData["result"] = num2 != 0 ? num1 / num2 : "Cannot divide by zero.";
            }
            else if (Request.Form["SQUARE"] == "SQUARE")
            {
                ViewData["result"] = Math.Pow(num1, 2);
            }
            else if (Request.Form["CUBE"] == "CUBE")
            {
                ViewData["result"] = Math.Pow(num1, 3);
            }
            else if (Request.Form["POWER"] == "POWER")
            {
                ViewData["result"] = Math.Pow(num1, num2);
            }
            else if (Request.Form["SIGN"] == "SIGN")
            {
                ViewData["result"] = num1 * -1;
            }
            else if (Request.Form["COS"] == "COS")
            {
                ViewData["result"] = Math.Cos(num1);
            }
            else if (Request.Form["TAN"] == "TAN")
            {
                ViewData["result"] = Math.Tan(num1);
            }
        }
    }
}
